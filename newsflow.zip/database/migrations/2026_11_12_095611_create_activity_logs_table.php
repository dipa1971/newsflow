<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::create('activity_logs', function (Blueprint $table) {
        $table->id();
        $table->foreignId('site_id')->nullable()->constrained()->cascadeOnDelete();
        $table->foreignId('article_id')->nullable()->constrained()->nullOnDelete();
        $table->string('level', 10)->default('info');
        $table->text('message');
        $table->timestamps();

        $table->index(['site_id', 'created_at']);
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('activity_logs');
    }
};
